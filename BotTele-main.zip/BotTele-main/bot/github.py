import requests

def register_github(bot):
    @bot.message_handler(commands=['github']) 
    def handle_infogithub(message): 
        try: 
            username = message.text.split()[1]  
            api_url = f"https://api.github.com/users/{username}" 
            response = requests.get(api_url) 
            data = response.json() 
     
            if response.status_code == 200:
                avatar_url = data.get('avatar_url', 'Không có avatar')
                caption = f"""
🎯═══════════════════════════════════🎯
║                                   ║
║         🐙 THÔNG TIN GITHUB       ║
║                                   ║
🎯═══════════════════════════════════🎯

👤 <b>Tên người dùng:</b> {data.get('login', 'Không có')}
🆔 <b>ID:</b> {data.get('id', 'Không có')}
📝 <b>Tên hiển thị:</b> {data.get('name', 'Không có')} 
📄 <b>Giới thiệu:</b> {data.get('bio', 'Chưa có')}

📊 <b>THỐNG KÊ:</b>
├─ 📚 Repositories: {data.get('public_repos', 0)}
├─ 👥 Người theo dõi: {data.get('followers', 0)}
└─ 💫 Đang theo dõi: {data.get('following', 0)}

📅 <b>Ngày tạo:</b> {data.get('created_at', 'Không rõ')}
🔗 <b>Link:</b> {data.get('html_url', 'Không có')}

🎯═══════════════════════════════════🎯
║                                   ║
║        🚀 Bot Bóng X 2025 🚀      ║
║                                   ║
🎯═══════════════════════════════════🎯
"""
     
                bot.send_photo(message.chat.id, avatar_url, caption=caption) 
            else: 
                bot.reply_to(message, "❌ Không tìm thấy thông tin GitHub của người dùng này. Vui lòng kiểm tra lại tên!") 
     
        except IndexError: 
            bot.reply_to(message, "🚫 Vui lòng cung cấp username cần check. Ví dụ: /github tên")
