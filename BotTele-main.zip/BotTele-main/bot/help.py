def register_help(bot):
    @bot.message_handler(commands=['help', 'start'])
    def send_help(message):
        help_text = """
🎯═══════════════════════════════════🎯
║                                   ║
║         ⚡ BOT BÓNG X ⚡          ║
║                                   ║
🎯═══════════════════════════════════🎯

🏠 ┌─── CHỨC NĂNG CƠ BẢN ───┐ 🏠
   │                          │
   │ 📋 /help    ➤ Menu bot   │
   │ 👑 /admin   ➤ Thông tin  │  
   │ 🕒 /time    ➤ Thời gian  │
   │                          │
   └─────────────────────────┘

⚡ ┌──── CÔNG CỤ MẠNH ─────┐ ⚡
   │                          │
   │ 🌐 /proxy   ➤ Proxy VIP  │
   │ 🐙 /github  ➤ Phân tích  │
   │ 🖼️ /images  ➤ Lấy ảnh    │
   │ 🎵 /scl     ➤ Tải nhạc   │
   │ 🎨 /thumb   ➤ Thumbnail  │
   │ 💾 /sourceweb ➤ Mã nguồn │
   │ 📹 /send    ➤ Tải video  │
   │ 🎭 /tiktok  ➤ TikTok     │
   │ 👤 /in4     ➤ Thông tin  │
   │                          │
   └─────────────────────────┘

🎪 ┌───── GIẢI TRÍ ──────┐ 🎪
   │                       │
   │ 😂 /meme  ➤ Ảnh hài   │
   │ 👸 /girl  ➤ Video     │
   │ 🍥 /anime ➤ Anime     │
   │                       │
   └──────────────────────┘

🎯═══════════════════════════════════🎯
║                                   ║
║    🚀 Tạo bởi Bóng X • 2025 🚀    ║
║                                   ║
🎯═══════════════════════════════════🎯
"""
        bot.reply_to(message, help_text)
