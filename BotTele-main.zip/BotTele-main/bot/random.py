import random
from config import ADMIN_ID, ERROR_MSG

MAX_ATTEMPTS = 5

def send_random_media(bot, message, file_path, media_type):
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            urls = [line.strip() for line in file if line.strip()]
    except Exception as e:
        bot.send_message(ADMIN_ID, f"⚠️ Lỗi: {e}")
        return bot.reply_to(message, ERROR_MSG)

    if not urls:
        return bot.reply_to(message, "Danh sách chưa có dữ liệu!")

    random.shuffle(urls)

    send_func = {
        "photo": bot.send_photo,
        "video": bot.send_video,
        "animation": bot.send_animation,
    }.get(media_type)

    if not send_func:
        bot.send_message(ADMIN_ID, f"⚠️ Lệnh /{message.text} có media_type không hợp lệ: {media_type}")
        return bot.reply_to(message, ERROR_MSG)
        
    for attempts, url in enumerate(urls[:MAX_ATTEMPTS]):
        try:
            # Gửi media với caption đẹp
            caption = f"""
🎯═══════════════════════════════════🎯
║                                   ║
║         🎲 NỘI DUNG NGẪU NHIÊN    ║
║                                   ║
🎯═══════════════════════════════════🎯

🎯 <b>Lệnh:</b> /{message.text.split()[0][1:].upper()}
🔥 <b>Nội dung mới</b> từ bộ sưu tập
✨ <b>Chọn ngẫu nhiên</b> dành cho bạn!

🎯═══════════════════════════════════🎯
║                                   ║
║        � Bot Bóng X 2025 🚀      ║
║                                   ║
🎯═══════════════════════════════════🎯
"""
            
            if media_type == "video":
                bot.send_video(message.chat.id, url, caption=caption, reply_to_message_id=message.message_id)
            elif media_type == "photo":
                bot.send_photo(message.chat.id, url, caption=caption, reply_to_message_id=message.message_id)
            else:
                bot.send_animation(message.chat.id, url, caption=caption, reply_to_message_id=message.message_id)
            return
        except Exception as e:
            bot.send_message(
                ADMIN_ID,
                f"""
🚨 <b>RANDOM CONTENT ERROR</b>

📅 <b>Time:</b> {message.date}
👤 <b>User:</b> @{message.from_user.username or 'Unknown'}
🆔 <b>User ID:</b> {message.from_user.id}
🎯 <b>Command:</b> /{message.text}
🔗 <b>URL:</b> {url}
⚠️ <b>Error:</b> {e}

────────────────────────────────────
🔧 <b>Action Required:</b> Check media source
"""
            )

    error_msg = """
🎯═══════════════════════════════════🎯
║                                   ║
║          ⚠️ LỖI NỘI DUNG          ║
║                                   ║
🎯═══════════════════════════════════🎯

🚨 Không thể tải nội dung lúc này
📂 Kho nội dung đang được cập nhật
🔄 Vui lòng thử lại sau ít phút

💡 <b>Hoặc thử các lệnh khác:</b>
• /meme - Meme hài hước
• /help - Xem tất cả lệnh

🎯═══════════════════════════════════🎯
║                                   ║
║        🚀 Bot Bóng X 2025 🚀      ║
║                                   ║
🎯═══════════════════════════════════🎯
"""
    bot.reply_to(message, error_msg)


COMMANDS = {
    "anime": {
        "path": "bot/url/anime.txt",
        "type": "video"
    },
    "girl": {
        "path": "bot/url/girl.txt",
        "type": "video"
    }
    # Removed adult content entries:
    # imganime, butt, cosplay, pussy, nude, squeeze
}

def create_handler(bot, path, mtype):
    def handler(message):
        send_random_media(bot, message, path, mtype)
    return handler

def register_random(bot):
    for cmd, cfg in COMMANDS.items():
        handler = create_handler(bot, cfg["path"], cfg["type"])
        bot.register_message_handler(handler, commands=[cmd])
