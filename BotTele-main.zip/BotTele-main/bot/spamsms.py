import os
import threading
import subprocess
from datetime import datetime
from config import ADMIN_ID, GROUP_ID

VIP_FILE = "bot/spamsms/vip.txt"

last_sms_time = {}
last_smsvip_time = {}
sms_process = None
smsvip_process = None

def is_vip(user_id):
    if not os.path.exists(VIP_FILE):
        return False
    with open(VIP_FILE, "r") as f:
        vip_ids = [line.strip() for line in f.readlines()]
    return str(user_id) in vip_ids

def register_spamsms(bot):
    @bot.message_handler(commands=['add'])
    def add(message):
        if message.chat.id not in GROUP_ID or message.from_user.id != ADMIN_ID:
            error_msg = """
╔═══════════════════════════════╗
║          🚫 LỖI QUYỀN         ║
╚═══════════════════════════════╝

❌ <b>Truy cập bị từ chối!</b>
🔐 Chỉ có Admin mới có quyền thực hiện lệnh này

💡 <i>Liên hệ Admin để được hỗ trợ</i>
            """
            bot.reply_to(message, error_msg.strip())
            return

        args = message.text.split()
        if len(args) < 2 or not args[1].isdigit():
            help_msg = """
╔═══════════════════════════════╗
║         📖 HƯỚNG DẪN          ║
╚═══════════════════════════════╝

🔧 <b>Cú pháp:</b> <code>/add [user_id]</code>

📝 <b>Ví dụ:</b> <code>/add 123456789</code>

⚠️ <i>User ID phải là số nguyên</i>
            """
            bot.reply_to(message, help_msg.strip())
            return

        user_id = args[1].strip()
        if not os.path.exists(VIP_FILE):
            open(VIP_FILE, "w").close()

        with open(VIP_FILE, "r") as f:
            if user_id in f.read():
                exist_msg = f"""
╔═══════════════════════════════╗
║        ⚠️ NGƯỜI DÙNG ĐÃ TỒN TẠI ║
╚═══════════════════════════════╝

👤 <b>User ID:</b> <code>{user_id}</code>
💎 <b>Trạng thái:</b> Đã có VIP

✅ <i>Người dùng này đã được kích hoạt VIP trước đó</i>
                """
                bot.reply_to(message, exist_msg.strip())
                return

        with open(VIP_FILE, "a") as f:
            f.write(f"{user_id}\n")

        success_msg = f"""
╔═══════════════════════════════╗
║      🎉 KÍCH HOẠT THÀNH CÔNG  ║
╚═══════════════════════════════╝

👤 <b>User ID:</b> <code>{user_id}</code>
💎 <b>Gói:</b> VIP Premium
🚀 <b>Trạng thái:</b> Đã kích hoạt

🌟 <i>Chúc mừng! Người dùng đã được nâng cấp lên VIP</i>
        """
        bot.reply_to(message, success_msg.strip())

    @bot.message_handler(commands=['sms'])
    def sms(message):
        if message.chat.id not in GROUP_ID:
            return

        user_id = message.from_user.id
        now = datetime.now()

        if user_id in last_sms_time and (now - last_sms_time[user_id]).total_seconds() < 100:
            remaining_time = 100 - int((now - last_sms_time[user_id]).total_seconds())
            cooldown_msg = f"""
╔═══════════════════════════════╗
║         ⏰ THỜI GIAN CHỜ      ║
╚═══════════════════════════════╝

� <b>Vui lòng đợi:</b> <code>{remaining_time}</code> giây
🔄 <b>Lý do:</b> Tránh spam hệ thống
⚡ <b>Loại:</b> SMS Standard

💡 <i>Hãy kiên nhẫn để có trải nghiệm tốt nhất!</i>
            """
            bot.reply_to(message, cooldown_msg.strip())
            return

        args = message.text.split()
        if len(args) != 3 or not args[1].isdigit() or not args[2].isdigit():
            help_msg = """
╔═══════════════════════════════╗
║         � HƯỚNG DẪN SMS      ║
╚═══════════════════════════════╝

🔧 <b>Cú pháp:</b> <code>/sms [sđt] [vòng_lặp]</code>

📱 <b>Ví dụ:</b> <code>/sms 0987654321 10</code>

📋 <b>Quy tắc:</b>
   • SĐT: 10 số, bắt đầu bằng 0
   • Vòng lặp: 1-100
   • Thời gian chờ: 100 giây

🚀 <i>Sử dụng /smsvip để có tốc độ cao hơn!</i>
            """
            bot.reply_to(message, help_msg.strip())
            return

        phone, loops = args[1], int(args[2])
        if len(phone) != 10 or not phone.startswith("0") or loops > 100:
            error_msg = """
╔═══════════════════════════════╗
║         ❌ THÔNG TIN SAI       ║
╚═══════════════════════════════╝

📱 <b>Lỗi số điện thoại:</b>
   • Phải có đúng 10 số
   • Bắt đầu bằng số 0
   • Chỉ chứa số

🔢 <b>Lỗi vòng lặp:</b>
   • Tối đa 100 vòng lặp
   • Phải là số nguyên dương

💡 <i>Kiểm tra lại thông tin và thử lại!</i>
            """
            bot.reply_to(message, error_msg.strip())
            return

        last_sms_time[user_id] = now
        
        # Thông báo bắt đầu với animation
        start_msg = f"""
╔═══════════════════════════════╗
║      🚀 KHỞI ĐỘNG SMS ATTACK  ║
╚═══════════════════════════════╝

📱 <b>Số điện thoại:</b> <code>{phone}</code>
🔄 <b>Vòng lặp:</b> <code>{loops}</code>
⚡ <b>Server:</b> Standard #1
🕐 <b>Thời gian:</b> {now.strftime('%H:%M:%S')}

� <b>Trạng thái:</b> <i>Đang khởi tạo...</i>
⏳ <i>Quá trình sẽ hoàn thành trong vài phút</i>

🔥 <b>Attack đã bắt đầu!</b>
        """
        bot.reply_to(message, start_msg.strip())

        global sms_process
        if sms_process and sms_process.poll() is None:
            sms_process.terminate()

        sms_process = subprocess.Popen(["python", "bot/spamsms/sms.py", phone, str(loops)])

        def stop_after():
            import time
            time.sleep(200)
            if sms_process and sms_process.poll() is None:
                sms_process.terminate()
                complete_msg = f"""
╔═══════════════════════════════╗
║      ✅ HOÀN THÀNH SMS ATTACK ║
╚═══════════════════════════════╝

📱 <b>Số điện thoại:</b> <code>{phone}</code>
✅ <b>Trạng thái:</b> Đã hoàn thành
⏱️ <b>Thời gian:</b> 200 giây

🎉 <i>Attack đã kết thúc thành công!</i>
                """
                try:
                    bot.send_message(message.chat.id, complete_msg.strip())
                except:
                    pass

        threading.Thread(target=stop_after).start()

    @bot.message_handler(commands=['smsvip'])
    def smsvip(message):
        if message.chat.id not in GROUP_ID:
            return

        user_id = message.from_user.id
        now = datetime.now()

        if not is_vip(user_id):
            vip_msg = """
╔═══════════════════════════════╗
║        💎 VIP REQUIRED        ║
╚═══════════════════════════════╝

🚫 <b>Truy cập bị hạn chế!</b>
💎 <b>Yêu cầu:</b> Tài khoản VIP Premium

🌟 <b>Ưu đãi VIP:</b>
   • ⚡ Tốc độ cao hơn 5x
   • 🔥 Server chuyên dụng
   • ⏰ Cooldown chỉ 60s
   • 🎯 Độ chính xác cao

💰 <b>Liên hệ:</b> /admin để nâng cấp VIP
🎁 <i>Ưu đãi đặc biệt cho khách hàng mới!</i>
            """
            bot.reply_to(message, vip_msg.strip())
            return

        if user_id in last_smsvip_time and (now - last_smsvip_time[user_id]).total_seconds() < 60:
            remaining_time = 60 - int((now - last_smsvip_time[user_id]).total_seconds())
            cooldown_msg = f"""
╔═══════════════════════════════╗
║      ⏰ VIP COOLDOWN TIME     ║
╚═══════════════════════════════╝

� <b>Vui lòng đợi:</b> <code>{remaining_time}</code> giây
💎 <b>Loại tài khoản:</b> VIP Premium
⚡ <b>Server:</b> High-Speed #2

🌟 <i>VIP có thời gian chờ ngắn hơn!</i>
            """
            bot.reply_to(message, cooldown_msg.strip())
            return

        args = message.text.split()
        if len(args) != 3 or not args[1].isdigit() or not args[2].isdigit():
            help_msg = """
╔═══════════════════════════════╗
║      � HƯỚNG DẪN SMS VIP     ║
╚═══════════════════════════════╝

🔧 <b>Cú pháp:</b> <code>/smsvip [sđt] [vòng_lặp]</code>

📱 <b>Ví dụ:</b> <code>/smsvip 0987654321 50</code>

💎 <b>Đặc quyền VIP:</b>
   • 📱 SĐT: 10 số, bắt đầu bằng 0
   • 🔢 Vòng lặp: 1-100
   • ⏰ Cooldown: 60 giây
   • ⚡ Tốc độ: Premium

🚀 <i>Tận hưởng sức mạnh VIP!</i>
            """
            bot.reply_to(message, help_msg.strip())
            return

        phone, loops = args[1], int(args[2])
        if len(phone) != 10 or not phone.startswith("0") or loops > 100:
            error_msg = """
╔═══════════════════════════════╗
║      ❌ VIP INPUT ERROR       ║
╚═══════════════════════════════╝

� <b>Lỗi số điện thoại:</b>
   • Phải có đúng 10 số
   • Bắt đầu bằng số 0
   • Chỉ chứa ký tự số

🔢 <b>Lỗi vòng lặp:</b>
   • Tối đa 100 vòng lặp
   • Phải là số nguyên dương

💎 <i>VIP cần thông tin chính xác để hoạt động!</i>
            """
            bot.reply_to(message, error_msg.strip())
            return

        last_smsvip_time[user_id] = now
        
        # Thông báo VIP đặc biệt
        start_msg = f"""
╔═══════════════════════════════╗
║    💎 VIP SMS ATTACK LAUNCH   ║
╚═══════════════════════════════╝

📱 <b>Target:</b> <code>{phone}</code>
🔄 <b>Cycles:</b> <code>{loops}</code>
⚡ <b>Server:</b> VIP Premium #2
🚀 <b>Speed:</b> High Performance
🕐 <b>Started:</b> {now.strftime('%H:%M:%S')}

💎 <b>VIP Status:</b> <i>Activated</i>
🎯 <b>Priority:</b> <i>Maximum</i>

🔥 <b>Premium Attack Initiated!</b>
⚡ <i>VIP享受最高优先级处理</i>
        """
        bot.reply_to(message, start_msg.strip())

        global smsvip_process
        if smsvip_process and smsvip_process.poll() is None:
            smsvip_process.terminate()

        smsvip_process = subprocess.Popen(["python", "bot/spamsms/smsvip.py", phone, str(loops)])

        def stop_after():
            import time
            time.sleep(600)
            if smsvip_process and smsvip_process.poll() is None:
                smsvip_process.terminate()
                complete_msg = f"""
╔═══════════════════════════════╗
║     ✅ VIP MISSION COMPLETE   ║
╚═══════════════════════════════╝

📱 <b>Target:</b> <code>{phone}</code>
✅ <b>Status:</b> Successfully Completed
💎 <b>VIP Bonus:</b> +20% Efficiency
⏱️ <b>Duration:</b> 600 seconds

🎉 <i>VIP Attack completed with premium results!</i>
🌟 <i>感谢使用VIP服务!</i>
                """
                try:
                    bot.send_message(message.chat.id, complete_msg.strip())
                except:
                    pass

        threading.Thread(target=stop_after).start()

    @bot.message_handler(commands=['smsinfo'])
    def sms_info(message):
        if message.chat.id not in GROUP_ID:
            return
        
        user_id = message.from_user.id
        is_user_vip = is_vip(user_id)
        
        info_msg = f"""
╔═══════════════════════════════╗
║       📊 SMS SYSTEM INFO      ║
╚═══════════════════════════════╝

👤 <b>User ID:</b> <code>{user_id}</code>
💎 <b>VIP Status:</b> {'✅ Premium' if is_user_vip else '❌ Standard'}

📱 <b>SMS Standard:</b>
   • 🕐 Cooldown: 100 giây
   • 🔢 Max loops: 100
   • ⚡ Speed: Normal
   • 🌐 Server: Standard #1

💎 <b>SMS VIP:</b>
   • 🕐 Cooldown: 60 giây  
   • 🔢 Max loops: 100
   • ⚡ Speed: High Performance
   • 🌐 Server: Premium #2

🎯 <b>Available Commands:</b>
   • <code>/sms [phone] [loops]</code> - Standard SMS
   • <code>/smsvip [phone] [loops]</code> - VIP SMS
   • <code>/smsinfo</code> - System Information
   • <code>/smsstatus</code> - Check Status

💰 <b>Upgrade to VIP:</b> /admin
        """
        bot.reply_to(message, info_msg.strip())

    @bot.message_handler(commands=['smsstatus'])
    def sms_status(message):
        if message.chat.id not in GROUP_ID:
            return
            
        user_id = message.from_user.id
        now = datetime.now()
        
        # Kiểm tra cooldown SMS thường
        sms_cooldown = 0
        if user_id in last_sms_time:
            sms_elapsed = (now - last_sms_time[user_id]).total_seconds()
            if sms_elapsed < 100:
                sms_cooldown = 100 - int(sms_elapsed)
        
        # Kiểm tra cooldown SMS VIP
        smsvip_cooldown = 0
        if user_id in last_smsvip_time:
            smsvip_elapsed = (now - last_smsvip_time[user_id]).total_seconds()
            if smsvip_elapsed < 60:
                smsvip_cooldown = 60 - int(smsvip_elapsed)
        
        # Kiểm tra process đang chạy
        sms_running = sms_process and sms_process.poll() is None
        smsvip_running = smsvip_process and smsvip_process.poll() is None
        
        status_msg = f"""
╔═══════════════════════════════╗
║       📈 REALTIME STATUS      ║
╚═══════════════════════════════╝

👤 <b>User:</b> <code>{user_id}</code>
🕐 <b>Time:</b> {now.strftime('%H:%M:%S - %d/%m/%Y')}

📱 <b>SMS Standard:</b>
   • 🔄 Status: {'🟢 Ready' if sms_cooldown == 0 else f'🔴 Cooldown {sms_cooldown}s'}
   • 🖥️ Process: {'🟢 Running' if sms_running else '⚪ Idle'}

💎 <b>SMS VIP:</b>
   • 🔄 Status: {'🟢 Ready' if smsvip_cooldown == 0 else f'🔴 Cooldown {smsvip_cooldown}s'}
   • 🖥️ Process: {'🟢 Running' if smsvip_running else '⚪ Idle'}

🎯 <b>System Health:</b> 🟢 All Systems Operational
⚡ <b>Server Load:</b> {'🟢 Low' if not (sms_running or smsvip_running) else '🟡 Active'}

🔄 <i>Auto-refresh: Use /smsstatus again</i>
        """
        bot.reply_to(message, status_msg.strip())