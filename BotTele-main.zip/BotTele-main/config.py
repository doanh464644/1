# ID Telegram của admin
ADMIN_ID = 7509896689

# 📌 Danh sách các nhóm được phép
GROUP_ID = [
    -1002256706038
]

# CHANNEL_ID = 

# ⚠️ Thông báo lỗi
ERROR_MSG = "⚠️ Đã xảy ra lỗi nội bộ.\nAdmin đang trong quá trình xử lý."
